# Nano Banana 寫實圖片 Prompt（40組）

固定前綴：
`Ultra-realistic photo, 4K, natural skin texture, accurate skin tones, soft bokeh, not cartoon.`

1. Same person in a minimalist coffee shop, holding iced latte, relaxed smile, natural window light.
2. Same person in coworking space, laptop open with analytics chart, confident expression, clean composition.
3. Same person on city rooftop at sunset, wind in hair, cinematic golden hour, fashion editorial look.
4. Same person in gym mirror selfie setup, athleisure outfit, high contrast but natural skin detail.
5. Same person in skincare vanity setup, white robe, soft frontal lighting, premium beauty ad style.
6. Same person in neon cyberpunk alley, reflective jacket, moody contrast, shallow depth of field.
7. Same person reading notebook at desk, overhead lamp, cozy productivity aesthetic.
8. Same person in studio portrait, black background, rim light, luxury magazine style.
9. Same person in travel airport scene, carry-on luggage, candid walking shot.
10. Same person in kitchen meal prep scene, healthy lifestyle vibe, bright natural light.
11-40. 依主題替換場景即可。
