# Veo 3.1 9:16 短片 Prompt（40組）

公式：
`9:16 portrait, [subject], [single action], [camera move], [lighting], [mood], [ambient audio]`

1. 9:16 portrait, confident young woman in modern cafe, looks up and smiles, slow dolly-in, warm window light, optimistic mood, ambient cafe sounds.
2. 9:16 portrait, creator checking crypto dashboard on phone, subtle nod, handheld micro-shake camera, neon night lighting, focused mood, soft city ambience.
3. 9:16 portrait, fitness coach tying ponytail before workout, medium shot to close-up, high-key gym lighting, energetic mood, light gym ambience.
4. 9:16 portrait, laptop screen glow on face, gentle turn to camera, slow pan right, low-light cinematic tone, curious mood, keyboard clicks.
5. 9:16 portrait, street fashion walk, confident stride, tracking shot, golden hour light, premium lifestyle mood, soft traffic ambience.
6. 9:16 portrait, skincare closeup, touching cheek naturally, macro push-in, soft diffused light, clean beauty mood, quiet room tone.
7. 9:16 portrait, entrepreneur at desk, points to sticky note "START", slow tilt-up, neutral daylight, motivational mood, paper rustle SFX.
8. 9:16 portrait, traveler at train window, looks outside then to lens, gentle rack focus, moody blue-hour light, reflective mood, train ambience.
9. 9:16 portrait, woman opening product package, surprise smile, top-down to front transition, bright studio light, review vibe, subtle paper sounds.
10. 9:16 portrait, typing on keyboard then thumbs up, locked-off camera with micro zoom, white office light, productive mood, keyboard ambience.
11-40. 請複製上述模板並替換 subject/action/camera/light/mood/audio 做批量生成。
