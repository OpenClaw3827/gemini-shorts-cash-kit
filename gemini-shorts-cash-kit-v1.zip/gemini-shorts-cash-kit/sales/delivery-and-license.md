# 交付與授權

- 付款幣種：USDT / USDC
- 網路：Polygon（優先）或 Ethereum
- 地址：0xdc4bbe2363dacce1104b5cd862a5d80b0480f1df

下單格式：
- 方案：Lite / Creator / Studio
- tx hash：0x...
- Email（可選）

授權：
- Lite：個人使用
- Creator：可商用輸出
- Studio：小團隊內部使用
- 禁止轉售原始檔案
